import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  Bug, 
  ArrowLeft, 
  Calendar, 
  Clock,
  AlertCircle,
  User,
  Users,
  Check,
  X,
  Laptop,
  Activity,
  Globe
} from 'lucide-react';
import { getBugById } from '../firebase/services';
import { Bug as BugType, BugStatus, BugPriority } from '../types/bug';
import StatusUpdater from '../components/bugs/StatusUpdater';

const BugDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [bug, setBug] = useState<BugType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchBug = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        const bugData = await getBugById(id);
        
        if (bugData) {
          setBug(bugData);
        } else {
          setError('Bug not found');
        }
      } catch (err) {
        console.error('Error fetching bug:', err);
        setError('Failed to load bug details');
      } finally {
        setLoading(false);
      }
    };
    
    fetchBug();
  }, [id]);
  
  const handleStatusUpdated = async () => {
    if (!id) return;
    
    try {
      const updatedBug = await getBugById(id);
      if (updatedBug) {
        setBug(updatedBug);
      }
    } catch (err) {
      console.error('Error refreshing bug:', err);
    }
  };
  
  const getBadgeForStatus = (status: BugStatus) => {
    switch (status) {
      case BugStatus.OPEN:
        return <span className="badge badge-open">Open</span>;
      case BugStatus.IN_PROGRESS:
        return <span className="badge badge-in-progress">In Progress</span>;
      case BugStatus.RESOLVED:
        return <span className="badge badge-resolved">Resolved</span>;
      case BugStatus.CLOSED:
        return <span className="badge badge-closed">Closed</span>;
      default:
        return <span className="badge badge-open">Open</span>;
    }
  };
  
  const getBadgeForPriority = (priority: BugPriority) => {
    switch (priority) {
      case BugPriority.LOW:
        return <span className="badge bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-200">Low</span>;
      case BugPriority.MEDIUM:
        return <span className="badge bg-accent-100 text-accent-800 dark:bg-accent-900 dark:text-accent-200">Medium</span>;
      case BugPriority.HIGH:
        return <span className="badge bg-warning-100 text-warning-800 dark:bg-warning-900 dark:text-warning-200">High</span>;
      case BugPriority.CRITICAL:
        return <span className="badge bg-error-100 text-error-800 dark:bg-error-900 dark:text-error-200">Critical</span>;
      default:
        return <span className="badge bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-200">Low</span>;
    }
  };
  
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <Bug size={32} className="text-primary-500 animate-pulse-slow mb-4" />
        <p className="text-neutral-500 dark:text-neutral-400">Loading bug details...</p>
      </div>
    );
  }
  
  if (error || !bug) {
    return (
      <div className="max-w-3xl mx-auto">
        <div className="bg-error-100 dark:bg-error-900 text-error-800 dark:text-error-200 p-6 rounded-lg">
          <h3 className="font-semibold text-lg mb-2">Error</h3>
          <p>{error || 'Bug not found'}</p>
          <Link to="/" className="mt-4 btn btn-ghost">
            <ArrowLeft size={18} />
            <span>Back to Dashboard</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 transition-colors"
          >
            <ArrowLeft size={16} />
            <span>Back to Dashboard</span>
          </button>
          
          {bug.aiAnalysis && (
            <Link 
              to={`/ai-assistant?bugId=${bug.id}`}
              className="btn btn-secondary"
            >
              View AI Analysis
            </Link>
          )}
        </div>
        
        <div className="flex flex-col lg:flex-row justify-between gap-6">
          <div className="flex-grow space-y-6">
            <div className="card p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-2xl font-bold mb-2">{bug.title}</h1>
                  <div className="flex items-center gap-3 text-neutral-500 dark:text-neutral-400 text-sm">
                    <div className="flex items-center gap-1">
                      <Calendar size={14} />
                      <span>
                        {bug.createdAt instanceof Date 
                          ? bug.createdAt.toLocaleDateString() 
                          : 'Unknown date'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <User size={14} />
                      <span>{bug.reporter}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col items-end gap-2">
                  {getBadgeForStatus(bug.status)}
                  {getBadgeForPriority(bug.priority)}
                </div>
              </div>
              
              <div className="mb-6">
                <h2 className="text-lg font-semibold mb-2">Description</h2>
                <p className="text-neutral-700 dark:text-neutral-300 whitespace-pre-line">
                  {bug.description}
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h2 className="text-lg font-semibold mb-2">Steps to Reproduce</h2>
                  <div className="bg-neutral-50 dark:bg-neutral-800 p-4 rounded-md">
                    <p className="text-neutral-700 dark:text-neutral-300 whitespace-pre-line">
                      {bug.steps}
                    </p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-1 flex items-center gap-2">
                      <Check className="text-success-500" size={16} />
                      Expected Behavior
                    </h3>
                    <p className="text-neutral-700 dark:text-neutral-300">
                      {bug.expected}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-1 flex items-center gap-2">
                      <X className="text-error-500" size={16} />
                      Actual Behavior
                    </h3>
                    <p className="text-neutral-700 dark:text-neutral-300">
                      {bug.actual}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="card p-6">
              <h2 className="text-lg font-semibold mb-4">Environment</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Globe className="text-primary-500" size={18} />
                  <div>
                    <span className="text-sm text-neutral-500 dark:text-neutral-400">Environment</span>
                    <p className="font-medium">{bug.environment}</p>
                  </div>
                </div>
                
                {bug.browser && (
                  <div className="flex items-center gap-2">
                    <Globe className="text-primary-500" size={18} />
                    <div>
                      <span className="text-sm text-neutral-500 dark:text-neutral-400">Browser</span>
                      <p className="font-medium">{bug.browser}</p>
                    </div>
                  </div>
                )}
                
                {bug.os && (
                  <div className="flex items-center gap-2">
                    <Laptop className="text-primary-500" size={18} />
                    <div>
                      <span className="text-sm text-neutral-500 dark:text-neutral-400">Operating System</span>
                      <p className="font-medium">{bug.os}</p>
                    </div>
                  </div>
                )}
                
                {bug.device && (
                  <div className="flex items-center gap-2">
                    <Laptop className="text-primary-500" size={18} />
                    <div>
                      <span className="text-sm text-neutral-500 dark:text-neutral-400">Device</span>
                      <p className="font-medium">{bug.device}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="lg:w-[300px] space-y-6">
            <div className="card p-6">
              <h2 className="text-lg font-semibold mb-4">Status</h2>
              <StatusUpdater 
                bugId={bug.id} 
                currentStatus={bug.status}
                onStatusUpdated={handleStatusUpdated}
              />
            </div>
            
            <div className="card p-6">
              <h2 className="text-lg font-semibold mb-4">Assignment</h2>
              {bug.assignedTo ? (
                <div className="flex items-center gap-2">
                  <div className="bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-100 rounded-full h-10 w-10 flex items-center justify-center text-sm font-medium">
                    {bug.assignedTo.split(' ').map(name => name[0]).join('')}
                  </div>
                  <div>
                    <p className="font-medium">{bug.assignedTo}</p>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">Assigned</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                  <Users size={18} />
                  <span>Not assigned yet</span>
                </div>
              )}
            </div>
            
            <div className="card p-6">
              <h2 className="text-lg font-semibold mb-4">Activity</h2>
              <div className="space-y-3">
                <div className="flex items-start gap-2">
                  <Activity size={16} className="mt-1 text-primary-500" />
                  <div>
                    <p className="text-sm">
                      <span className="font-medium">{bug.reporter}</span>
                      <span className="text-neutral-500 dark:text-neutral-400"> created this bug</span>
                    </p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400">
                      {bug.createdAt instanceof Date 
                        ? bug.createdAt.toLocaleString() 
                        : 'Unknown date'}
                    </p>
                  </div>
                </div>
                
                {bug.updatedAt && bug.updatedAt.getTime() !== bug.createdAt.getTime() && (
                  <div className="flex items-start gap-2">
                    <Clock size={16} className="mt-1 text-primary-500" />
                    <div>
                      <p className="text-sm">
                        <span className="text-neutral-500 dark:text-neutral-400">Last updated</span>
                      </p>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">
                        {bug.updatedAt instanceof Date 
                          ? bug.updatedAt.toLocaleString() 
                          : 'Unknown date'}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default BugDetail;