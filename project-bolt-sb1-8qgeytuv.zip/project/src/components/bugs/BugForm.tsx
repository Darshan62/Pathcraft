import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useBugs } from '../../contexts/BugContext';
import { BugFormData, BugPriority } from '../../types/bug';
import { Bug, AlertTriangle, Clock, ArrowLeft } from 'lucide-react';

const BugForm: React.FC = () => {
  const navigate = useNavigate();
  const { createNewBug } = useBugs();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<BugFormData>({
    title: '',
    description: '',
    steps: '',
    expected: '',
    actual: '',
    environment: '',
    browser: '',
    os: '',
    device: '',
    priority: BugPriority.MEDIUM,
    reporter: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      const result = await createNewBug(formData);
      
      if (result.success) {
        setSuccess(true);
        setTimeout(() => {
          navigate('/');
        }, 2000);
      } else {
        setError('Failed to create bug. Please try again.');
      }
    } catch (err) {
      setError('An unexpected error occurred.');
      console.error('Error submitting bug:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 transition-colors"
          >
            <ArrowLeft size={16} />
            <span>Back to Dashboard</span>
          </button>
          
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Bug className="text-primary-500" />
            Report a Bug
          </h1>
        </div>

        {success ? (
          <motion.div
            className="bg-success-100 dark:bg-success-900 text-success-800 dark:text-success-200 p-4 rounded-md"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="font-semibold text-lg mb-2">Bug Successfully Reported!</h3>
            <p>Thank you for your report. Our team will look into it.</p>
            <div className="mt-4 w-full bg-success-200 dark:bg-success-800 rounded-full h-2">
              <motion.div 
                className="bg-success-500 h-2 rounded-full" 
                initial={{ width: 0 }}
                animate={{ width: '100%' }}
                transition={{ duration: 1.5 }}
              />
            </div>
            <p className="text-sm mt-2">Redirecting to dashboard...</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-error-100 dark:bg-error-900 text-error-800 dark:text-error-200 p-4 rounded-md flex items-start gap-2">
                <AlertTriangle className="mt-0.5" size={18} />
                <span>{error}</span>
              </div>
            )}
            
            <div className="card p-6">
              <h2 className="text-lg font-semibold mb-4">Bug Details</h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="title" className="form-label">Bug Title *</label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    className="form-input"
                    value={formData.title}
                    onChange={handleChange}
                    placeholder="Brief description of the issue"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="description" className="form-label">Detailed Description *</label>
                  <textarea
                    id="description"
                    name="description"
                    className="form-textarea"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Provide as much detail as possible about the bug"
                    rows={4}
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="steps" className="form-label">Steps to Reproduce *</label>
                    <textarea
                      id="steps"
                      name="steps"
                      className="form-textarea"
                      value={formData.steps}
                      onChange={handleChange}
                      placeholder="1. Navigate to page X\n2. Click on Y\n3. Observe error"
                      rows={3}
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label htmlFor="expected" className="form-label">Expected Behavior *</label>
                      <input
                        type="text"
                        id="expected"
                        name="expected"
                        className="form-input"
                        value={formData.expected}
                        onChange={handleChange}
                        placeholder="What should happen"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="actual" className="form-label">Actual Behavior *</label>
                      <input
                        type="text"
                        id="actual"
                        name="actual"
                        className="form-input"
                        value={formData.actual}
                        onChange={handleChange}
                        placeholder="What actually happened"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="card p-6">
              <h2 className="text-lg font-semibold mb-4">Environment</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="environment" className="form-label">Environment *</label>
                  <select
                    id="environment"
                    name="environment"
                    className="form-select"
                    value={formData.environment}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Environment</option>
                    <option value="development">Development</option>
                    <option value="staging">Staging</option>
                    <option value="production">Production</option>
                    <option value="testing">Testing</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="browser" className="form-label">Browser</label>
                  <input
                    type="text"
                    id="browser"
                    name="browser"
                    className="form-input"
                    value={formData.browser}
                    onChange={handleChange}
                    placeholder="Chrome, Firefox, Safari, etc."
                  />
                </div>
                
                <div>
                  <label htmlFor="os" className="form-label">Operating System</label>
                  <input
                    type="text"
                    id="os"
                    name="os"
                    className="form-input"
                    value={formData.os}
                    onChange={handleChange}
                    placeholder="Windows, macOS, Linux, etc."
                  />
                </div>
                
                <div>
                  <label htmlFor="device" className="form-label">Device</label>
                  <input
                    type="text"
                    id="device"
                    name="device"
                    className="form-input"
                    value={formData.device}
                    onChange={handleChange}
                    placeholder="Desktop, iPhone, Android, etc."
                  />
                </div>
              </div>
            </div>
            
            <div className="card p-6">
              <h2 className="text-lg font-semibold mb-4">Additional Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="priority" className="form-label">Priority *</label>
                  <select
                    id="priority"
                    name="priority"
                    className="form-select"
                    value={formData.priority}
                    onChange={handleChange}
                    required
                  >
                    <option value={BugPriority.LOW}>Low</option>
                    <option value={BugPriority.MEDIUM}>Medium</option>
                    <option value={BugPriority.HIGH}>High</option>
                    <option value={BugPriority.CRITICAL}>Critical</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="reporter" className="form-label">Your Name *</label>
                  <input
                    type="text"
                    id="reporter"
                    name="reporter"
                    className="form-input"
                    value={formData.reporter}
                    onChange={handleChange}
                    placeholder="Your name"
                    required
                  />
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                className="btn btn-primary min-w-[150px]"
                disabled={loading}
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <Clock className="animate-spin" size={18} />
                    <span>Submitting...</span>
                  </div>
                ) : (
                  'Submit Bug Report'
                )}
              </button>
            </div>
          </form>
        )}
      </motion.div>
    </div>
  );
};

export default BugForm;