export enum BugStatus {
  OPEN = 'open',
  IN_PROGRESS = 'in_progress',
  RESOLVED = 'resolved',
  CLOSED = 'closed'
}

export enum BugPriority {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

export interface Bug {
  id: string;
  title: string;
  description: string;
  steps: string;
  expected: string;
  actual: string;
  environment: string;
  browser?: string;
  os?: string;
  device?: string;
  screenshots?: string[];
  status: BugStatus;
  priority: BugPriority;
  reporter: string;
  assignedTo?: string;
  createdAt: Date;
  updatedAt: Date;
  aiAnalysis?: {
    cause?: string;
    solution?: string;
    accuracy?: number;
  };
}

export interface BugFormData {
  title: string;
  description: string;
  steps: string;
  expected: string;
  actual: string;
  environment: string;
  browser?: string;
  os?: string;
  device?: string;
  priority: BugPriority;
  reporter: string;
}