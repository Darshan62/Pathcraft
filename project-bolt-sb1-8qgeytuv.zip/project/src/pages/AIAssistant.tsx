import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { 
  Send, 
  ArrowLeft, 
  BrainCircuit, 
  Lightbulb, 
  Bug, 
  Settings, 
  ArrowRight,
  Clock
} from 'lucide-react';
import { getBugById } from '../firebase/services';
import { Bug as BugType } from '../types/bug';

const AIAssistant: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [bug, setBug] = useState<BugType | null>(null);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [message, setMessage] = useState('');
  const [conversation, setConversation] = useState<Array<{ role: 'user' | 'ai'; content: string }>>([
    { 
      role: 'ai', 
      content: 'Hi there! I\'m your AI bug assistant. I can help analyze bugs, suggest potential solutions, and provide debugging tips. How can I help you today?' 
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check if we have a bugId query param
    const queryParams = new URLSearchParams(location.search);
    const bugId = queryParams.get('bugId');
    
    if (bugId) {
      fetchBugDetails(bugId);
    }
  }, [location]);

  useEffect(() => {
    scrollToBottom();
  }, [conversation]);

  const fetchBugDetails = async (bugId: string) => {
    try {
      setLoading(true);
      const bugData = await getBugById(bugId);
      
      if (bugData) {
        setBug(bugData);
        
        // If the bug has AI analysis, add it to the conversation
        if (bugData.aiAnalysis) {
          setConversation(prev => [
            ...prev,
            { 
              role: 'ai', 
              content: `I've analyzed the bug "${bugData.title}" and here's what I found:\n\n` +
                       `Likely cause: ${bugData.aiAnalysis?.cause || 'Unknown'}\n\n` +
                       `Recommended solution: ${bugData.aiAnalysis?.solution || 'Unknown'}\n\n` +
                       `Analysis confidence: ${bugData.aiAnalysis?.accuracy ? `${bugData.aiAnalysis.accuracy}%` : 'Unknown'}`
            }
          ]);
        }
      }
    } catch (err) {
      console.error('Error fetching bug:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    // Add user message to conversation
    setConversation(prev => [...prev, { role: 'user', content: message }]);
    
    // Simulate AI analyzing
    setAnalyzing(true);
    
    // Clear input
    setMessage('');
    
    // Simulate AI response after a delay
    setTimeout(() => {
      let aiResponse = '';
      
      // Generate different responses based on message content
      if (message.toLowerCase().includes('bug') && message.toLowerCase().includes('cause')) {
        aiResponse = "Based on the symptoms you've described, this bug is likely caused by a race condition in the asynchronous code. When multiple requests happen simultaneously, the state management isn't properly handling the concurrent updates. I'd recommend implementing a proper locking mechanism or using a state management library that handles this scenario.";
      } else if (message.toLowerCase().includes('solution') || message.toLowerCase().includes('fix')) {
        aiResponse = "To fix this issue, I recommend:\n\n1. Implement proper state synchronization\n2. Add error boundaries to catch and handle unexpected states\n3. Consider using a mutex pattern for critical sections\n4. Add comprehensive logging to track the state changes\n5. Write unit tests that specifically target the race condition";
      } else if (message.toLowerCase().includes('error') || message.toLowerCase().includes('exception')) {
        aiResponse = "The error message suggests a null reference exception. This typically happens when the code tries to access a property or method on an object that is null. Check for any assumptions in your code about object initialization, especially after asynchronous operations.";
      } else {
        aiResponse = "I understand your question. To properly analyze this bug, I'd need more information about the specific symptoms, error messages, and the context in which the issue occurs. Could you provide more details about when the bug happens and any error messages you're seeing?";
      }
      
      // Add AI response to conversation
      setConversation(prev => [...prev, { role: 'ai', content: aiResponse }]);
      setAnalyzing(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col h-[calc(100vh-180px)]"
      >
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 transition-colors"
          >
            <ArrowLeft size={16} />
            <span>Back to Dashboard</span>
          </button>
          
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BrainCircuit className="text-secondary-500" />
            AI Bug Assistant
          </h1>
          
          {bug && (
            <Link
              to={`/bugs/${bug.id}`}
              className="flex items-center gap-2 text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 transition-colors"
            >
              <span>View Bug</span>
              <ArrowRight size={16} />
            </Link>
          )}
        </div>
        
        {bug && (
          <div className="bg-secondary-50 dark:bg-secondary-900/30 border border-secondary-200 dark:border-secondary-800 rounded-lg p-4 mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Bug className="text-secondary-500" size={18} />
              <h3 className="font-semibold">Currently Analyzing:</h3>
            </div>
            <p className="font-medium">{bug.title}</p>
            <p className="text-sm text-neutral-600 dark:text-neutral-400 line-clamp-2">{bug.description}</p>
          </div>
        )}
        
        <div className="flex-grow bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 overflow-hidden flex flex-col">
          <div className="flex-grow overflow-y-auto p-4">
            <div className="space-y-4">
              {conversation.map((msg, index) => (
                <motion.div
                  key={index}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div 
                    className={`max-w-[80%] rounded-lg p-3 ${
                      msg.role === 'user' 
                        ? 'bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-100' 
                        : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-100'
                    }`}
                  >
                    {msg.role === 'ai' && (
                      <div className="flex items-center gap-2 mb-1 pb-1 border-b border-neutral-200 dark:border-neutral-600">
                        <BrainCircuit size={16} className="text-secondary-500" />
                        <span className="text-xs font-medium">AI Assistant</span>
                      </div>
                    )}
                    <p className="whitespace-pre-line">{msg.content}</p>
                  </div>
                </motion.div>
              ))}
              
              {analyzing && (
                <motion.div
                  className="flex justify-start"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="max-w-[80%] rounded-lg p-3 bg-neutral-100 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-100">
                    <div className="flex items-center gap-2 mb-1 pb-1 border-b border-neutral-200 dark:border-neutral-600">
                      <BrainCircuit size={16} className="text-secondary-500" />
                      <span className="text-xs font-medium">AI Assistant</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="animate-spin" size={14} />
                      <span>Analyzing...</span>
                    </div>
                  </div>
                </motion.div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </div>
          
          <div className="border-t border-neutral-200 dark:border-neutral-700 p-3">
            <div className="flex items-center gap-2">
              <textarea
                className="flex-grow form-textarea min-h-[60px] resize-none"
                placeholder="Ask about bugs, solutions, or debugging tips..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyPress}
                disabled={analyzing}
              />
              <button
                className="btn btn-secondary h-[60px] w-[60px] flex-shrink-0"
                onClick={handleSendMessage}
                disabled={!message.trim() || analyzing}
              >
                <Send size={20} />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AIAssistant;