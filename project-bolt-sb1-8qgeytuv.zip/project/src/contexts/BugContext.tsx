import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { Bug, BugStatus, BugPriority } from '../types/bug';
import { getBugs, createBug, updateBugStatus, assignBug, updateBugPriority } from '../firebase/services';

interface BugContextType {
  bugs: Bug[];
  loading: boolean;
  error: string | null;
  createNewBug: (bugData: any) => Promise<{ success: boolean; id?: string; error?: any }>;
  updateStatus: (id: string, status: BugStatus) => Promise<{ success: boolean; error?: any }>;
  assignToTeamMember: (id: string, assignee: string) => Promise<{ success: boolean; error?: any }>;
  updatePriority: (id: string, priority: BugPriority) => Promise<{ success: boolean; error?: any }>;
  refreshBugs: () => Promise<void>;
}

const BugContext = createContext<BugContextType | undefined>(undefined);

export const BugProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bugs, setBugs] = useState<Bug[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBugs = async () => {
    try {
      setLoading(true);
      const fetchedBugs = await getBugs();
      setBugs(fetchedBugs);
      setError(null);
    } catch (err) {
      setError('Failed to fetch bugs. Please try again.');
      console.error('Error fetching bugs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBugs();
  }, []);

  const createNewBug = async (bugData: any) => {
    try {
      const result = await createBug(bugData);
      if (result.success) {
        await fetchBugs(); // Refresh bugs after creation
      }
      return result;
    } catch (err) {
      console.error('Error in createNewBug:', err);
      return { success: false, error: err };
    }
  };

  const updateStatus = async (id: string, status: BugStatus) => {
    try {
      const result = await updateBugStatus(id, status);
      if (result.success) {
        await fetchBugs(); // Refresh bugs after update
      }
      return result;
    } catch (err) {
      console.error('Error in updateStatus:', err);
      return { success: false, error: err };
    }
  };

  const assignToTeamMember = async (id: string, assignee: string) => {
    try {
      const result = await assignBug(id, assignee);
      if (result.success) {
        await fetchBugs(); // Refresh bugs after assignment
      }
      return result;
    } catch (err) {
      console.error('Error in assignToTeamMember:', err);
      return { success: false, error: err };
    }
  };

  const updatePriority = async (id: string, priority: BugPriority) => {
    try {
      const result = await updateBugPriority(id, priority);
      if (result.success) {
        await fetchBugs(); // Refresh bugs after priority update
      }
      return result;
    } catch (err) {
      console.error('Error in updatePriority:', err);
      return { success: false, error: err };
    }
  };

  const refreshBugs = async () => {
    await fetchBugs();
  };

  return (
    <BugContext.Provider 
      value={{ 
        bugs, 
        loading, 
        error, 
        createNewBug, 
        updateStatus, 
        assignToTeamMember, 
        updatePriority,
        refreshBugs
      }}
    >
      {children}
    </BugContext.Provider>
  );
};

export const useBugs = (): BugContextType => {
  const context = useContext(BugContext);
  if (context === undefined) {
    throw new Error('useBugs must be used within a BugProvider');
  }
  return context;
};