import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import { ThemeProvider } from './contexts/ThemeContext';
import { BugProvider } from './contexts/BugContext';
import { CustomCursor } from './components/ui/CustomCursor';

import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import BugDetail from './pages/BugDetail';
import NewBug from './pages/NewBug';
import AIAssistant from './pages/AIAssistant';
import NotFound from './pages/NotFound';

function App() {
  return (
    <ThemeProvider>
      <BugProvider>
        <Router>
          <CustomCursor />
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/bugs/new" element={<NewBug />} />
              <Route path="/bugs/:id" element={<BugDetail />} />
              <Route path="/ai-assistant" element={<AIAssistant />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Layout>
        </Router>
      </BugProvider>
    </ThemeProvider>
  );
}

export default App;