import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, AlertCircle, Clock, X } from 'lucide-react';
import { BugStatus } from '../../types/bug';
import { useBugs } from '../../contexts/BugContext';

interface StatusUpdaterProps {
  bugId: string;
  currentStatus: BugStatus;
  onStatusUpdated?: () => void;
}

const StatusUpdater: React.FC<StatusUpdaterProps> = ({ 
  bugId, 
  currentStatus,
  onStatusUpdated
}) => {
  const { updateStatus } = useBugs();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleStatusChange = async (newStatus: BugStatus) => {
    if (newStatus === currentStatus) return;
    
    setLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      const result = await updateStatus(bugId, newStatus);
      
      if (result.success) {
        setSuccess(`Status updated to ${formatStatus(newStatus)}`);
        
        // Clear success message after 3 seconds
        setTimeout(() => {
          setSuccess(null);
        }, 3000);
        
        if (onStatusUpdated) {
          onStatusUpdated();
        }
      } else {
        setError('Failed to update status');
      }
    } catch (err) {
      setError('An unexpected error occurred');
      console.error('Error updating status:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatStatus = (status: BugStatus): string => {
    return status
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const getStatusClass = (status: BugStatus): string => {
    if (status === currentStatus) {
      switch (status) {
        case BugStatus.OPEN:
          return 'bg-accent-500 text-white';
        case BugStatus.IN_PROGRESS:
          return 'bg-primary-500 text-white';
        case BugStatus.RESOLVED:
          return 'bg-success-500 text-white';
        case BugStatus.CLOSED:
          return 'bg-neutral-500 text-white';
        default:
          return 'bg-neutral-200 text-neutral-700 dark:bg-neutral-700 dark:text-neutral-200';
      }
    }
    
    return 'bg-neutral-200 text-neutral-700 hover:bg-neutral-300 dark:bg-neutral-700 dark:text-neutral-200 dark:hover:bg-neutral-600';
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        <button
          className={`px-3 py-2 rounded-md font-medium transition-colors ${getStatusClass(BugStatus.OPEN)}`}
          onClick={() => handleStatusChange(BugStatus.OPEN)}
          disabled={loading || currentStatus === BugStatus.OPEN}
        >
          Open
        </button>
        
        <button
          className={`px-3 py-2 rounded-md font-medium transition-colors ${getStatusClass(BugStatus.IN_PROGRESS)}`}
          onClick={() => handleStatusChange(BugStatus.IN_PROGRESS)}
          disabled={loading || currentStatus === BugStatus.IN_PROGRESS}
        >
          In Progress
        </button>
        
        <button
          className={`px-3 py-2 rounded-md font-medium transition-colors ${getStatusClass(BugStatus.RESOLVED)}`}
          onClick={() => handleStatusChange(BugStatus.RESOLVED)}
          disabled={loading || currentStatus === BugStatus.RESOLVED}
        >
          Resolved
        </button>
        
        <button
          className={`px-3 py-2 rounded-md font-medium transition-colors ${getStatusClass(BugStatus.CLOSED)}`}
          onClick={() => handleStatusChange(BugStatus.CLOSED)}
          disabled={loading || currentStatus === BugStatus.CLOSED}
        >
          Closed
        </button>
      </div>
      
      {loading && (
        <div className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
          <Clock size={16} className="animate-spin" />
          <span>Updating status...</span>
        </div>
      )}
      
      {error && (
        <motion.div
          className="flex items-center gap-2 text-error-600 dark:text-error-400"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <AlertCircle size={16} />
          <span>{error}</span>
          <button 
            onClick={() => setError(null)}
            className="ml-auto text-neutral-500 hover:text-neutral-700 dark:text-neutral-400 dark:hover:text-neutral-200"
          >
            <X size={14} />
          </button>
        </motion.div>
      )}
      
      {success && (
        <motion.div
          className="flex items-center gap-2 text-success-600 dark:text-success-400"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          transition={{ duration: 0.3 }}
        >
          <CheckCircle size={16} />
          <span>{success}</span>
        </motion.div>
      )}
    </div>
  );
};

export default StatusUpdater;