import { 
  collection, 
  addDoc, 
  updateDoc, 
  doc, 
  getDoc, 
  getDocs, 
  query, 
  orderBy, 
  Timestamp,
  serverTimestamp
} from 'firebase/firestore';
import { db } from './config';
import { Bug, BugStatus, BugPriority } from '../types/bug';

const bugsCollection = collection(db, 'bugs');

// Create a new bug
export const createBug = async (bugData: Omit<Bug, 'id' | 'createdAt' | 'updatedAt'>) => {
  try {
    const docRef = await addDoc(bugsCollection, {
      ...bugData,
      status: BugStatus.OPEN,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    
    return { id: docRef.id, success: true };
  } catch (error) {
    console.error('Error creating bug:', error);
    return { success: false, error };
  }
};

// Get all bugs
export const getBugs = async () => {
  try {
    const bugsQuery = query(bugsCollection, orderBy('updatedAt', 'desc'));
    const querySnapshot = await getDocs(bugsQuery);
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate(),
    } as Bug));
  } catch (error) {
    console.error('Error getting bugs:', error);
    return [];
  }
};

// Get a single bug by ID
export const getBugById = async (id: string) => {
  try {
    const docRef = doc(db, 'bugs', id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        ...data,
        createdAt: data.createdAt?.toDate(),
        updatedAt: data.updatedAt?.toDate(),
      } as Bug;
    } else {
      return null;
    }
  } catch (error) {
    console.error('Error getting bug:', error);
    return null;
  }
};

// Update a bug
export const updateBug = async (id: string, updates: Partial<Omit<Bug, 'id' | 'createdAt' | 'updatedAt'>>) => {
  try {
    const docRef = doc(db, 'bugs', id);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp(),
    });
    
    return { success: true };
  } catch (error) {
    console.error('Error updating bug:', error);
    return { success: false, error };
  }
};

// Update bug status
export const updateBugStatus = async (id: string, newStatus: BugStatus) => {
  return updateBug(id, { status: newStatus });
};

// Assign bug to a team member
export const assignBug = async (id: string, assignedTo: string) => {
  return updateBug(id, { assignedTo });
};

// Update bug priority
export const updateBugPriority = async (id: string, priority: BugPriority) => {
  return updateBug(id, { priority });
};