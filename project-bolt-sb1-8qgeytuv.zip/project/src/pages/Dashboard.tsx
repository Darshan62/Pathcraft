import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Bug, Filter, RefreshCw, Plus, Search } from 'lucide-react';
import { useBugs } from '../contexts/BugContext';
import BugCard from '../components/bugs/BugCard';
import { BugStatus, BugPriority } from '../types/bug';

const Dashboard: React.FC = () => {
  const { bugs, loading, error, refreshBugs } = useBugs();
  const [filteredBugs, setFilteredBugs] = useState(bugs);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<BugStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<BugPriority | 'all'>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    let result = [...bugs];
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(bug => 
        bug.title.toLowerCase().includes(query) || 
        bug.description.toLowerCase().includes(query)
      );
    }
    
    // Apply status filter
    if (statusFilter !== 'all') {
      result = result.filter(bug => bug.status === statusFilter);
    }
    
    // Apply priority filter
    if (priorityFilter !== 'all') {
      result = result.filter(bug => bug.priority === priorityFilter);
    }
    
    setFilteredBugs(result);
  }, [bugs, searchQuery, statusFilter, priorityFilter]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refreshBugs();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 500);
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
        <motion.h1 
          className="text-3xl font-bold flex items-center gap-2"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Bug className="text-primary-500" />
          Bug Dashboard
        </motion.h1>
        
        <motion.div 
          className="flex items-center gap-2"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <button 
            onClick={handleRefresh} 
            className="btn btn-ghost"
            disabled={isRefreshing}
          >
            <RefreshCw size={18} className={isRefreshing ? 'animate-spin' : ''} />
            <span className="hidden sm:inline">Refresh</span>
          </button>
          
          <Link to="/bugs/new" className="btn btn-primary">
            <Plus size={18} />
            <span>New Bug</span>
          </Link>
        </motion.div>
      </div>
      
      <motion.div 
        className="mb-6 card p-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-grow relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" size={18} />
            <input
              type="text"
              placeholder="Search bugs..."
              className="form-input pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center gap-2">
              <Filter size={18} className="text-neutral-500" />
              <select
                className="form-select"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as BugStatus | 'all')}
              >
                <option value="all">All Statuses</option>
                <option value={BugStatus.OPEN}>Open</option>
                <option value={BugStatus.IN_PROGRESS}>In Progress</option>
                <option value={BugStatus.RESOLVED}>Resolved</option>
                <option value={BugStatus.CLOSED}>Closed</option>
              </select>
            </div>
            
            <select
              className="form-select"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value as BugPriority | 'all')}
            >
              <option value="all">All Priorities</option>
              <option value={BugPriority.LOW}>Low</option>
              <option value={BugPriority.MEDIUM}>Medium</option>
              <option value={BugPriority.HIGH}>High</option>
              <option value={BugPriority.CRITICAL}>Critical</option>
            </select>
          </div>
        </div>
      </motion.div>
      
      {loading ? (
        <div className="flex flex-col items-center justify-center py-12">
          <Bug size={32} className="text-primary-500 animate-pulse-slow mb-4" />
          <p className="text-neutral-500 dark:text-neutral-400">Loading bugs...</p>
        </div>
      ) : error ? (
        <div className="bg-error-100 dark:bg-error-900 text-error-800 dark:text-error-200 p-6 rounded-lg">
          <h3 className="font-semibold text-lg mb-2">Error Loading Bugs</h3>
          <p>{error}</p>
          <button 
            onClick={handleRefresh}
            className="mt-4 btn btn-ghost"
          >
            <RefreshCw size={18} />
            <span>Try Again</span>
          </button>
        </div>
      ) : filteredBugs.length === 0 ? (
        <motion.div 
          className="flex flex-col items-center justify-center py-12 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <Bug size={32} className="text-neutral-400 mb-4" />
          {bugs.length === 0 ? (
            <>
              <h3 className="text-xl font-semibold mb-2">No Bugs Reported Yet</h3>
              <p className="text-neutral-500 dark:text-neutral-400 max-w-md mb-4">
                Looks like there are no bugs reported yet. Start tracking issues by creating your first bug report.
              </p>
              <Link to="/bugs/new" className="btn btn-primary">
                <Plus size={18} />
                <span>Report a Bug</span>
              </Link>
            </>
          ) : (
            <>
              <h3 className="text-xl font-semibold mb-2">No Matching Bugs</h3>
              <p className="text-neutral-500 dark:text-neutral-400 max-w-md mb-4">
                No bugs match your current search filters. Try adjusting your search or filters to see more results.
              </p>
              <button 
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('all');
                  setPriorityFilter('all');
                }}
                className="btn btn-primary"
              >
                Clear Filters
              </button>
            </>
          )}
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBugs.map((bug, index) => (
            <BugCard key={bug.id} bug={bug} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;