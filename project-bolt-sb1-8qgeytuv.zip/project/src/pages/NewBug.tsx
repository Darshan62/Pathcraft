import React from 'react';
import BugForm from '../components/bugs/BugForm';

const NewBug: React.FC = () => {
  return <BugForm />;
};

export default NewBug;