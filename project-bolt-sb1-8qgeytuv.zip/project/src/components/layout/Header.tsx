import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Moon, Sun, Bug, Plus, BrainCircuit } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <motion.header 
      className="sticky top-0 z-10 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-md border-b border-neutral-200 dark:border-neutral-800"
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.1, duration: 0.4 }}
    >
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-semibold text-xl">
          <Bug className="h-6 w-6 text-primary-500" />
          <span>DevBugTracker</span>
        </Link>
        
        <div className="flex items-center gap-4">
          <Link 
            to="/ai-assistant" 
            className="flex items-center gap-2 px-3 py-2 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <BrainCircuit size={20} className="text-secondary-500" />
            <span className="hidden sm:inline">AI Assistant</span>
          </Link>
          
          <Link 
            to="/bugs/new" 
            className="btn btn-primary"
          >
            <Plus size={18} />
            <span className="hidden sm:inline">Report Bug</span>
          </Link>
          
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
          >
            {theme === 'light' ? (
              <Moon size={20} className="text-neutral-700" />
            ) : (
              <Sun size={20} className="text-neutral-300" />
            )}
          </button>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;