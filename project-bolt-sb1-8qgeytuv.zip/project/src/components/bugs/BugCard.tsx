import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Calendar, User, ArrowRight, AlertCircle } from 'lucide-react';
import { Bug, BugStatus, BugPriority } from '../../types/bug';

interface BugCardProps {
  bug: Bug;
}

const BugCard: React.FC<BugCardProps> = ({ bug }) => {
  const getPriorityColor = (priority: BugPriority) => {
    switch (priority) {
      case BugPriority.LOW:
        return 'bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-200';
      case BugPriority.MEDIUM:
        return 'bg-accent-100 text-accent-800 dark:bg-accent-900 dark:text-accent-200';
      case BugPriority.HIGH:
        return 'bg-warning-100 text-warning-800 dark:bg-warning-900 dark:text-warning-200';
      case BugPriority.CRITICAL:
        return 'bg-error-100 text-error-800 dark:bg-error-900 dark:text-error-200';
      default:
        return 'bg-neutral-100 text-neutral-800 dark:bg-neutral-800 dark:text-neutral-200';
    }
  };

  const getStatusBadge = (status: BugStatus) => {
    switch (status) {
      case BugStatus.OPEN:
        return <span className="badge badge-open">Open</span>;
      case BugStatus.IN_PROGRESS:
        return <span className="badge badge-in-progress">In Progress</span>;
      case BugStatus.RESOLVED:
        return <span className="badge badge-resolved">Resolved</span>;
      case BugStatus.CLOSED:
        return <span className="badge badge-closed">Closed</span>;
      default:
        return <span className="badge badge-open">Open</span>;
    }
  };

  return (
    <motion.div 
      className="card overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -4 }}
    >
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="font-semibold text-lg mb-1 line-clamp-1">{bug.title}</h3>
            <div className="flex items-center gap-2 text-sm text-neutral-500 dark:text-neutral-400">
              <Calendar size={14} />
              <span>
                {bug.createdAt instanceof Date 
                  ? bug.createdAt.toLocaleDateString() 
                  : 'Unknown date'}
              </span>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-2">
            {getStatusBadge(bug.status)}
            <span className={`badge ${getPriorityColor(bug.priority)}`}>
              {bug.priority.charAt(0).toUpperCase() + bug.priority.slice(1)}
            </span>
          </div>
        </div>
        
        <p className="text-neutral-600 dark:text-neutral-300 mb-4 line-clamp-2">
          {bug.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1 text-sm text-neutral-500 dark:text-neutral-400">
            <User size={14} />
            <span>{bug.assignedTo || 'Unassigned'}</span>
          </div>
          
          <Link 
            to={`/bugs/${bug.id}`} 
            className="flex items-center gap-1 text-sm font-medium text-primary-600 dark:text-primary-400 hover:underline"
          >
            View Details
            <ArrowRight size={14} />
          </Link>
        </div>
      </div>
      
      {bug.priority === BugPriority.CRITICAL && (
        <div className="bg-error-50 dark:bg-error-950 text-error-600 dark:text-error-400 p-2 flex items-center gap-2 text-sm">
          <AlertCircle size={14} />
          <span>Critical issue - needs immediate attention</span>
        </div>
      )}
    </motion.div>
  );
};

export default BugCard;